package com.jp.dao.dto;

public class NotoficationDto {

	private String message;
	private String messageStatus;
	private String logicStatus;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageStatus() {
		return messageStatus;
	}

	public void setMessageStatus(String messageStatus) {
		this.messageStatus = messageStatus;
	}

	public String getLogicStatus() {
		return logicStatus;
	}

	public void setLogicStatus(String logicStatus) {
		this.logicStatus = logicStatus;
	}
	
	
}
