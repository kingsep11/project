package com.jp.dao.dto;

public class ProofileDto {

}
