package com.jp.dao.impl;

import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.gson.Gson;
import com.jp.dao.UserDao;
import com.jp.dao.dto.UserDto;
import com.jp.dao.rm.LoginUserRM;
import com.jp.dao.rm.UserRM;
import com.jp.service.vo.UserVO;
import com.jp.util.MessageConstants;

public class UserDaoImpl implements UserDao{
	
	private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

	@Override
	public UserVO getUsers() {
		System.out.println("Dao layer.....................................................");
		final String USER_QRY = "SELECT * FROM USER_CREDENTIALS";
		UserVO userVO = new UserVO();
		try{
			List<UserDto> userList = (List<UserDto>) this.jdbcTemplate.query(USER_QRY, new UserRM());
			userVO.setUserList(userList);
			System.out.println(userList.size());
		}catch (Exception e) {
			e.printStackTrace();
		}
		return userVO;
	}

	@Override
	public UserDto saveUser(String jsonstr) {
		final String ADD_USER_QRY = "INSERT INTO USER_CREDENTIALS (USER_NAME,PASSWORD,ACTIVE,CREATED_DATE,USER_EMAIL,USER_MOBILE) VALUES (?,?,?,?,?,?)";
		//final String NEW_USER_VERIFICATION_QRY = "INSERT INTO USER_PROFILE";
		
		UserDto user = new UserDto();
			Gson gson=new Gson();
			Date date =new Date();
			user =  gson.fromJson(jsonstr, UserDto.class);
			int userId=0;
			
			try{
				userId = getUserId(user);
			if(userId > 0){
				user.setLogicStatus(MessageConstants.LOGIC_STATUS_FAIL);
				user.setMessageStatus(MessageConstants.MESSAGE_TYPE_ALERT);
				user.setMessage(MessageConstants.USER_EXIST);	
			}else{
				this.jdbcTemplate.update(ADD_USER_QRY, new Object[]{
						user.getUserName(),
						user.getPassword(),
						user.getActive(),
						date,
						user.getEmail(),
						user.getPhone()
				});
			System.out.println("user inserted successfully....");
			user.setMessage(MessageConstants.USER_REGISTRATION_WELCOME);
			user.setLogicStatus(MessageConstants.LOGIC_STATUS_SUCCESS);
			user.setMessageStatus(MessageConstants.MESSAGE_TYPE_SUCCESS);
			userId = getUserId(user);
			}
			user.setUid(userId);
			return user;
			
		}catch (Exception e) {
			e.printStackTrace();
			user.setLogicStatus(MessageConstants.LOGIC_STATUS_FAIL);
			user.setMessageStatus(MessageConstants.MESSAGE_TYPE_ERROR);
			user.setMessage(MessageConstants.USER_SAVE_ERROR);
			return user;
		}
	}
	
	
	public int getUserId(UserDto user){
		final String SELECT_NEW_USER_QRY = "SELECT UID FROM USER_CREDENTIALS WHERE USER_EMAIL=? OR USER_NAME=? OR PASSWORD=?";
		int userId=0;
		try{
			userId = (Integer)this.jdbcTemplate.queryForInt(SELECT_NEW_USER_QRY, new Object[]{user.getEmail(),user.getUserName(),user.getPhone()});
		}catch (EmptyResultDataAccessException e) {
			System.out.println("User doesnt exist....");
		}
		return userId;
	}

	@Override
	public UserDto getUser(String jsonstr) {
		final String SELECT_LOGIN_USER_QRY = "SELECT UID,USER_NAME,ACTIVE,USER_EMAIL,USER_MOBILE,ISADMIN FROM USER_CREDENTIALS WHERE USER_NAME=? OR PASSWORD=?";
		final String SELECT_LOGIN_USER_COUNT_QRY = "SELECT COUNT(UID) FROM USER_CREDENTIALS WHERE USER_NAME=? OR PASSWORD=?";

		UserDto user = new UserDto();
		Gson gson=new Gson();
		user =  gson.fromJson(jsonstr, UserDto.class);
		int userCount=0;
		try{
			userCount = (Integer)this.jdbcTemplate.queryForInt(SELECT_LOGIN_USER_COUNT_QRY, new Object[]{user.getUserName(),user.getPassword()});
			
		}catch (Exception e) {
			System.out.println("exception in user count....");
			user.setLogicStatus(MessageConstants.LOGIC_STATUS_FAIL);
			user.setMessageStatus(MessageConstants.MESSAGE_TYPE_ERROR);
			user.setMessage(MessageConstants.USER_LOGIN_ERROR);
		}

		if(userCount>0 && userCount==1){
			try{
				user = (UserDto)this.jdbcTemplate.queryForObject(SELECT_LOGIN_USER_QRY, new Object[]{user.getUserName(),user.getPassword()},new LoginUserRM());
				user.setMessage(MessageConstants.USER_LOGIN_SUCCESS);
				user.setLogicStatus(MessageConstants.LOGIC_STATUS_SUCCESS);
			}catch (EmptyResultDataAccessException e) {
				System.out.println("Logn User doesnt exist....");
				user.setMessage(MessageConstants.USER_LOGIN_ERROR);
			}
		}else{
			user.setLogicStatus(MessageConstants.LOGIC_STATUS_FAIL);
			user.setMessageStatus(MessageConstants.MESSAGE_TYPE_ERROR);
			user.setMessage(MessageConstants.USER_LOGIN_ERROR);
			
		}
		return user;
	}

}
