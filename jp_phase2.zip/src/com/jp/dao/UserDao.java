package com.jp.dao;

import com.jp.dao.dto.UserDto;
import com.jp.service.vo.UserVO;

public interface UserDao {

	UserVO getUsers();
	UserDto saveUser(String jsonstr);
	UserDto getUser(String jsonstr);
}
