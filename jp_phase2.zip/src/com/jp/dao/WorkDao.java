package com.jp.dao;

import com.jp.dao.dto.WorkDto;
import com.jp.service.vo.WorkVO;

public interface WorkDao {

	WorkVO getWorks(String listfor);
	WorkVO findWorks(String srchString) ;
	WorkDto postWorks(String srchString) ;
	String updateWorks(String jobId);
}
