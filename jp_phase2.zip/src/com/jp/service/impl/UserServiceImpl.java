package com.jp.service.impl;

import com.jp.dao.UserDao;
import com.jp.dao.dto.UserDto;
import com.jp.service.UserService;
import com.jp.service.vo.UserVO;
import com.jp.util.ApplicationContextProvider;

public class UserServiceImpl implements UserService{

	@Override
	public String sayHello() {
		System.out.println(">>>>>>>>>>>>>>>");
		return "Hello Raja";
	}

	@Override
	public UserVO getUsers() {
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		UserDao user = (UserDao) appContext.getApplicationContext().getBean("userDao");
		return user.getUsers();
	}

	@Override
	public UserDto saveusers(String jsonStr) {
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		UserDao user = (UserDao) appContext.getApplicationContext().getBean("userDao");
		return user.saveUser(jsonStr);
	}

	@Override
	public UserDto getuser(String jsonStr) {
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		UserDao user = (UserDao) appContext.getApplicationContext().getBean("userDao");
		return user.getUser(jsonStr);
	}

}
