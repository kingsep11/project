define(['jquery','jquery_dataTables'], function ($) {
	return function(){
		console.log("home section called....");
		
		$(".post-job").click(function(){
			console.log("post job clicked....");
			window.location.href="postjob.html";
		});
		
		$(".browse-job").click(function(){
			console.log("browse job clicked.........");
			window.location.href="listing.html";
		});
		
		$("#loginbtn").click(function(){
			console.log("login clicked....");
			window.location.href="login.html";
		});
		
		$("#signupbtn").click(function(){
			console.log("login clicked....");
			window.location.href="login.html";
		});
		
	};
});