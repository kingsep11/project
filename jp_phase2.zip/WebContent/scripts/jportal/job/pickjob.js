define(['jquery','jquery_dataTables','common'], function ($,$datatable,$common) {
	return function(){
		$common.pageControlBySession("pickjob.html");
		$common.chkUserSession();
		$common.bindMenukEvents();
		
		function showJobDetails(){
			var jobId = sessionStorage.getItem('selectedJobId');
			var jobtitle=sessionStorage.getItem('selectedJobTitle');
			var jobdescr=sessionStorage.getItem('selectedJobDescr');
			var jobbudget=sessionStorage.getItem('selectedJobBudget');
			
			$(".project_name").html(jobtitle);
			$(".jobdescr").html(jobdescr);
			
			if(sessionStorage.getItem("listJobevtType")=="LIST"){
				$("#project_status").html("Active");
			}
			if(sessionStorage.getItem("listJobevtType")=="APROVE"){
				$("#project_status").html("Pending Approval");
				$(".repostProjectButton").html("Approve")
			}
		}
		
		$(".repostProjectButton").click(function(){
			
		});

	}
});