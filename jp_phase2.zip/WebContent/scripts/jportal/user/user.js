define(['jquery','jquery_dataTables','common'], function ($,$datatable,$common) {
	// for all user related functionalities
	
	return function(){
		console.log("users script loaded.....");
		
		$(".lnkSignup").click(function(){
			console.log("signup link clicked....");
			$("#signup").show();
			$("#login").hide();
			$("#forgot-password").hide();
		});
		
		$("#lnkForgotPassword").click(function(){
			$("#signup").hide();
			$("#login").hide();
			$("#forgot-password").show();
		});
		
		$(".signup-btn").click(function(){
			var user = {
					"id":"",
					"userName":$("#signupusername").val(),
					"email":$("#signupemail").val(),
					"phone":$("#signup-mobile").val(),
					"password":$("#signuppassword").val(),
					"active":'Y',
					"isadmin":'N',
					"createdDate":new Date()
			};
			
			saveUser(user);
			
		});
		
		
		/**
		 * For login functionality
		 * **/
		
		$("#login-bt").click(function(){
			var credential={
					"userName":$("#login-sername").val(),
					"password":$("#login-password").val(),
			};
			loginUser(credential);
		});
		
		
		
		/**Login action **/
		function loginUser(credential){
			
			$.ajax({
			    url: './webserviceInvokeservlet?wsname=getuser',
			    dataType: 'json',
			    type: 'POST',
			    contentType: 'application/json;charset=UTF-8',
			    data: JSON.stringify(credential),
			    success: function( data, textStatus, jQxhr ){
			        
			        if(data.userDto.logicStatus=='Y'){
			        	sessionStorage.setItem('user', JSON.stringify(data));
			        	window.location.href="listing.html";
			        }else{
			        	console.log("Show error message....");
			        }
			    },
			    error: function( jqXhr, textStatus, errorThrown ){
			        console.log( errorThrown );
			    },
			    complete:function(){
			    	//$(".form-error").html(messageFromServer);
			    }
			});
		}
		
		function saveUser(user){
			var messageFromServer="",messageStatus="",logicStatus="";
			$.ajax({
			    url: './webserviceInvokeservlet?wsname=saveusers',
			    dataType: 'json',
			    type: 'POST',
			    contentType: 'application/json;charset=UTF-8',
			    data: JSON.stringify(user),
			    success: function( data, textStatus, jQxhr ){
			        console.log("post service success....");
			        console.log(JSON.stringify(data));
			        messageFromServer=data.userDto.message;
			        messageStatus=data.userDto.messageStatus;
			        logicStatus=data.userDto.logicStatus;

			    },
			    error: function( jqXhr, textStatus, errorThrown ){
			        console.log( errorThrown );
			        $common.showNotification("N","E","Applciation Error with user registration ! Please click <a href=login.html>here</a> to back to application ");
			    },
			    complete:function(){
			    	$(".form-error").html(messageFromServer);
			    	$common.showNotification(logicStatus,messageStatus,messageFromServer);
			    }
			});
		}
	}
});