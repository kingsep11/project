jQuery(document).ready(function() {
    var first = true;

    var poll = function() {
        jQuery.ajax({
            url: '/online-count/view/',
            type: 'GET',
            dataType: 'jsonp',
            jsonp: 'callback',
            data: 'page=' + window.location.pathname + '&first=' + first,
            success: function(json) {
                first = false;
                //console.log(json);
            }
        });
    };
    poll();
    setInterval(poll, 30000);

});
