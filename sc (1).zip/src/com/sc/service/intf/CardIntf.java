package com.sc.service.intf;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.sc.vo.CardVO;


@Path("/webservice")
public interface CardIntf {

	@GET
	@Path("sayhello")
	String sayHello();
	
	@GET
	@Produces("application/json")
	@Path("getCardList")
	CardVO getCardList(@QueryParam("cardType") String cardType);
	
}
