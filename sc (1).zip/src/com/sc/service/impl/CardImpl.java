package com.sc.service.impl;

import com.sc.util.ApplicationContextProvider;
import com.sc.dao.CardDao;
import com.sc.service.intf.CardIntf;
import com.sc.vo.CardVO;

public class CardImpl implements CardIntf{

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
				return "this is say hello service";
	}

	@Override
	public CardVO getCardList(String cardType) {
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		CardDao cardDao = (CardDao)appContext.getApplicationContext().getBean("cardDao");
		return cardDao.getCardList(cardType);
	}

}
