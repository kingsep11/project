package com.sc.util;

public class SCQueryConstants {

	public static final String QRY_CARD_LST_BY_TYPE = "select name,price,ptype from cards where ptype=?";
}
