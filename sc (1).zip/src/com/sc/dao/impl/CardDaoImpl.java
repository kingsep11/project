package com.sc.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.sc.dao.CardDao;
import com.sc.dao.dto.CardDto;
import com.sc.dao.rm.CardRM;
import com.sc.util.SCQueryConstants;
import com.sc.vo.CardVO;

public class CardDaoImpl implements CardDao{

	private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

	
	@Override
	public CardVO getCardList(String cardType) {
		// TODO Auto-generated method stub
		CardVO cardVO = new CardVO();
		List<CardDto> cardList = (List<CardDto>) this.jdbcTemplate.query(SCQueryConstants.QRY_CARD_LST_BY_TYPE, new Object[] {cardType},new CardRM());
		cardVO.setCardList(cardList);
		return cardVO;
	}

}
