package com.sc.dao;

import com.sc.vo.CardVO;

public interface CardDao {

	CardVO getCardList(String cardType);
}
