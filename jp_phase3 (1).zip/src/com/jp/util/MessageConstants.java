package com.jp.util;

public interface MessageConstants {

	/** For General **/
	
	public static final String MESSAGE_TYPE_SUCCESS = "S";
	public static final String MESSAGE_TYPE_ALERT = "A";
	public static final String MESSAGE_TYPE_ERROR = "E";
	
	/** For logical status **/
	public static final String LOGIC_STATUS_SUCCESS = "Y";
	public static final String LOGIC_STATUS_FAIL = "N";
	
	/** For users **/
	public static final String USER_REGISTRATION_WELCOME = "Welcome to our portal";
	public static final String USER_EXIST = "User Already exist with same Username or email or mobile";
	public static final String USER_SAVE_ERROR = "Error On Registration";
	public static final String USER_LOGIN_ERROR = "Invalid Credentials";
	public static final String USER_LOGIN_SUCCESS = "Login Success";
	
	/** For Jobs **/
	public static final String WORK_ALREADY_EXIST = "Duplicate Entry!";
	public static final String WORK_SAVED_SUCCESS = "Posted Successfully! your jon will be active shortly";
	public static final String WORK_SAVED_ERROR = "Error when saving job!";

}
