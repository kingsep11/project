package com.jp.dao.rm;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.jp.dao.dto.WorkDto;

public class WorkRM implements RowMapper{

	@Override
	public WorkDto mapRow(ResultSet rs, int arg1) throws SQLException {
		
		WorkDto workDto = new WorkDto();
		workDto.setWorkId(rs.getInt(1));
		workDto.setWorkTitle(rs.getString(2));
		workDto.setWorkDesc(rs.getString(3));
		workDto.setBudgetType(rs.getInt(4));
		workDto.setListType(rs.getInt(5));
		workDto.setOwnerId(rs.getInt(6));
		workDto.setCreatedDate(rs.getString(7));
		workDto.setSkillset(rs.getString(8));
		workDto.setMinBudget(rs.getString(9));
		workDto.setMaxBudget(rs.getString(10));
		
		return workDto;
	}

}
