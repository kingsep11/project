package com.jp.dao.rm;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.jp.dao.dto.UserDto;

public class LoginUserRM implements RowMapper{

	@Override
	public UserDto mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		
		UserDto userDto = new UserDto();
		userDto.setUid(rs.getInt(1));
		userDto.setUserName(rs.getString(2));
		userDto.setActive(rs.getString(3));
		userDto.setEmail(rs.getString(4));
		userDto.setPhone(rs.getString(5));
		userDto.setIsadmin(rs.getString(6));
		return userDto;
	}

}
