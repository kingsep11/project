package com.jp.dao.impl;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.gson.Gson;
import com.jp.dao.WorkDao;
import com.jp.dao.dto.WorkDto;
import com.jp.dao.rm.WorkRM;
import com.jp.service.vo.WorkVO;
import com.jp.util.MessageConstants;

public class WorkDaoImpl implements WorkDao{

	private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

	@Override
	public WorkVO getWorks(String listfor) {
		WorkVO workVO = new WorkVO();
		try {
			System.out.println(""+this.jdbcTemplate.getDataSource().getConnection().isClosed());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String WORK_LIST_QRY = "";
		if(listfor.equals("APPROVE")){
			WORK_LIST_QRY = "SELECT  a.work_id,  c.work_title,  c.work_desc,  c.budget_type,  c.list_type,  c.work_owner,  c.created_date,  GROUP_CONCAT(b.skillset_name SEPARATOR ', ') AS skills,  d.min_budget,  d.max_budget FROM  map_work_skillset a,  mstr_skillset b,  work_master c,  work_budget d  WHERE c.work_id = a.work_id  AND c.work_id = d.work_id  AND a.skillset_id = b.skill_id and c.approved='N' GROUP BY work_id";
		}else{
			WORK_LIST_QRY = "SELECT  a.work_id,  c.work_title,  c.work_desc,  c.budget_type,  c.list_type,  c.work_owner,  c.created_date,  GROUP_CONCAT(b.skillset_name SEPARATOR ', ') AS skills,  d.min_budget,  d.max_budget FROM  map_work_skillset a,  mstr_skillset b,  work_master c,  work_budget d  WHERE c.work_id = a.work_id  AND c.work_id = d.work_id  AND a.skillset_id = b.skill_id and c.approved='Y' GROUP BY work_id";
		}
		try{
			List<WorkDto> workList = (List<WorkDto>) this.jdbcTemplate.query(WORK_LIST_QRY, new WorkRM());
			System.out.println(workList.size());
			workVO.setWorkList(workList);
		}catch(Exception e){
			e.printStackTrace();
		}
		return workVO;
	}


	public WorkVO findWorks(String srchString) {
		WorkVO workVO = new WorkVO();
		//final String WORK_LIST_QRY = "SELECT * FROM WORK_MASTER";
		String[] splitups = srchString.split(" ");
		String WORK_LIST_QRY = "SELECT  a.work_id,  c.work_title,  c.work_desc,  c.budget_type,  c.list_type,  c.work_owner,  c.created_date,  GROUP_CONCAT(b.skillset_name SEPARATOR ', ') AS skills,  d.min_budget,  d.max_budget FROM  map_work_skillset a,  mstr_skillset b,  work_master c,  work_budget d  WHERE c.work_id = a.work_id  AND c.work_id = d.work_id  AND a.skillset_id = b.skill_id and (";

		for(int i=0;i<splitups.length;i++){
			if(i==splitups.length-1){
				WORK_LIST_QRY = WORK_LIST_QRY+" instr(c.work_title,'"+splitups[i]+"')";
			}else{
				WORK_LIST_QRY = WORK_LIST_QRY+" instr(c.work_title,'"+splitups[i]+"') or ";
			}
		}

		WORK_LIST_QRY = WORK_LIST_QRY+") GROUP BY work_id";
		
		System.out.println(WORK_LIST_QRY);
		try{
			List<WorkDto> workList = (List<WorkDto>) this.jdbcTemplate.query(WORK_LIST_QRY, new WorkRM());
			System.out.println(workList.size());
			workVO.setWorkList(workList);
		}catch(Exception e){
			e.printStackTrace();
		}
		return workVO;
	}

	@Override
	public WorkDto postWorks(String jsonstr) {
		final String SAVE_JOB_QUERY="insert into work_master(work_title,work_desc,budget_type,list_type,work_owner,created_date)"
				+ "values(?,?,?,?,?,?)";
		
		Gson gson = new Gson();
		WorkDto work = gson.fromJson(jsonstr, WorkDto.class);
		
		/** checking if the work already exist and inserting **/
		int work_id = getWork(work.getWorkTitle(),work.getOwnerId());
		try{
			if(work_id == 0){ /**the job is not duplicate one**/
				this.jdbcTemplate.update(SAVE_JOB_QUERY, new Object[]{work.getWorkTitle(),work.getWorkDesc(),work.getBudgetType(),work.getListType(),work.getOwnerId(),new Date()});
				work_id = getWork(work.getWorkTitle(),work.getOwnerId());
				work.setWorkId(work_id);
				saveWorkBudget(work_id,work.getMinBudget()); /** For saving budget **/
				saveWorkSkillset(work_id,"1"); /** For saving the budget **/
				
				work.setMessageStatus(MessageConstants.MESSAGE_TYPE_SUCCESS);
				work.setMessage(MessageConstants.WORK_ALREADY_EXIST);
				work.setLogicStatus(MessageConstants.LOGIC_STATUS_SUCCESS);
			}
			else if(work_id>0){ /** the job is duplicated**/
				work.setWorkId(work_id);
				work.setMessageStatus(MessageConstants.MESSAGE_TYPE_ALERT);
				work.setMessage(MessageConstants.WORK_ALREADY_EXIST);
			}
		}catch (Exception e) {
			e.printStackTrace();
			work.setMessageStatus(MessageConstants.MESSAGE_TYPE_ERROR);
			work.setMessage(MessageConstants.WORK_SAVED_ERROR);
		}
		return work;
	}
	
	
	public void saveWorkBudget(int workId,String budget){
		final String SAVE_WORK_BUDGET = "insert into work_budget(work_id,min_budget) values(?,?)";
		try{
			this.jdbcTemplate.update(SAVE_WORK_BUDGET, new Object[]{workId,Float.valueOf(budget)});
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public void saveWorkSkillset(int workId,String skillId){
		final String SAVE_WORK_SKILL = "insert into map_work_skillset(work_id,skillset_id) values(?,?)";
		try{
			this.jdbcTemplate.update(SAVE_WORK_SKILL, new Object[]{workId,skillId});
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public int getWork(String worktitle,int ownerId){
		final String FIND_JOB_ID = "select work_id from work_maser where work_title=? and work_owner=?";
		try{
			int jobId = (Integer)this.jdbcTemplate.queryForInt(FIND_JOB_ID,new Object[]{worktitle,ownerId});
			return jobId;
		}catch (EmptyResultDataAccessException e) {
			return 0;
		}
	}
	
	
	/** for approving job **/
	public String updateWorks(String jobId){
		final String UPDATE_JOB = "update work_master set approved='Y' where work_id=?";
		try{
			this.jdbcTemplate.update(UPDATE_JOB,new Object[]{jobId});
			return "Updated Successfully !";
		}catch (Exception e) {
			e.printStackTrace();
			return "Failed to update";
		}
	}

	@Override
	public String applyproject(String jobId, String userid) {
		final String UPDATE_JOB = "insert into work_bid(work_id,user_id,created_date) values(?,?,?)";
		try{
			this.jdbcTemplate.update(UPDATE_JOB,new Object[]{jobId,userid,new Date()});
			return "Updated Successfully !";
		}catch (Exception e) {
			e.printStackTrace();
			return "Failed to update";
		}
	}

}
