package com.jp.dao.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class WorkDto extends NotoficationDto{

	private int workId;
	private String workTitle;
	private String workDesc;
	private int budgetType;
	private int listType;
	private int ownerId;
	private String createdDate;
	private String skillset;
	private String minBudget;
	private String maxBudget;
	private String approved;
	private String saved;
	
	public int getWorkId() {
		return workId;
	}
	public void setWorkId(int workId) {
		this.workId = workId;
	}
	public String getWorkTitle() {
		return workTitle;
	}
	public void setWorkTitle(String workTitle) {
		this.workTitle = workTitle;
	}
	public String getWorkDesc() {
		return workDesc;
	}
	public void setWorkDesc(String workDesc) {
		this.workDesc = workDesc;
	}
	public int getBudgetType() {
		return budgetType;
	}
	public void setBudgetType(int budgetType) {
		this.budgetType = budgetType;
	}
	public int getListType() {
		return listType;
	}
	public void setListType(int listType) {
		this.listType = listType;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getSkillset() {
		return skillset;
	}
	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}
	public String getMinBudget() {
		return minBudget;
	}
	public void setMinBudget(String minBudget) {
		this.minBudget = minBudget;
	}
	public String getMaxBudget() {
		return maxBudget;
	}
	public void setMaxBudget(String maxBudget) {
		this.maxBudget = maxBudget;
	}
	
	
	
	
}
