package com.jp.service.impl;

import com.jp.dao.UserDao;
import com.jp.dao.WorkDao;
import com.jp.dao.dto.WorkDto;
import com.jp.service.WorkService;
import com.jp.service.vo.WorkVO;
import com.jp.util.ApplicationContextProvider;

public class WorkServiceImpl implements WorkService{
	
	public WorkVO getWorks(String srchFlag,String srchString,String listfor){
		WorkVO vorkVO = new WorkVO();
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		WorkDao work = (WorkDao) appContext.getApplicationContext().getBean("workDao");
		if(srchFlag.equals("F")){
		vorkVO= work.getWorks(listfor);
		}
		else{
			vorkVO= work.findWorks(srchString);
		}
		
		return vorkVO;
	}

	@Override
	public WorkDto savework(String jsonStr) {
		WorkVO vorkVO = new WorkVO();
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		WorkDao work = (WorkDao) appContext.getApplicationContext().getBean("workDao");
		return work.postWorks(jsonStr);
	}

	@Override
	public String updateWorks(String jobId) {
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		WorkDao work = (WorkDao) appContext.getApplicationContext().getBean("workDao");
		return work.updateWorks(jobId);
	}

	@Override
	public String applyproject(String jobId, String userid) {
		ApplicationContextProvider appContext = new ApplicationContextProvider();
		WorkDao work = (WorkDao) appContext.getApplicationContext().getBean("workDao");
		return work.applyproject(jobId, userid);
	}


}
