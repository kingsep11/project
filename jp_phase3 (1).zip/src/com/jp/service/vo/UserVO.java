package com.jp.service.vo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.jp.dao.dto.UserDto;
@XmlRootElement
public class UserVO {

	List<UserDto> userList = new ArrayList<>();

	public List<UserDto> getUserList() {
		return userList;
	}

	public void setUserList(List<UserDto> userList) {
		this.userList = userList;
	}
	
}
