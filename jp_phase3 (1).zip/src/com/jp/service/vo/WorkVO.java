package com.jp.service.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.jp.dao.dto.WorkDto;
@XmlRootElement
public class WorkVO {

	private List<WorkDto> workList;

	public List<WorkDto> getWorkList() {
		return workList;
	}

	public void setWorkList(List<WorkDto> workList) {
		this.workList = workList;
	}
	
	
}
