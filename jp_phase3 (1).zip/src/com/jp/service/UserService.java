package com.jp.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.jp.dao.dto.UserDto;
import com.jp.service.vo.UserVO;

@Path("/webservice")
public interface UserService {

	@GET
	@Path("sayhello")
	String sayHello();

	@GET
	@Path("getusers")
	@Produces("application/json")
	UserVO getUsers();
	
	@POST
	@Path("saveusers")
	@Produces("application/json")
	UserDto saveusers(String jsonStr);
	
	
	@POST
	@Path("getuser")
	@Produces("application/json")
	UserDto getuser(String jsonStr);

}
