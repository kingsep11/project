package com.jp.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.jp.dao.dto.WorkDto;
import com.jp.service.vo.WorkVO;
@Path("/webservice")
public interface WorkService {
	
	@GET
	@Path("getWorks")
	@Produces("application/json")
	WorkVO getWorks(@QueryParam("srchFlag") String srchFlag,@QueryParam("srchString") String srchString,@QueryParam("listfor") String listfor);

	@POST
	@Path("savework")
	@Produces("application/json")
	WorkDto savework(String jsonStr);

	@GET
	@Path("approveproject")
	@Produces("application/json")
	String updateWorks(@QueryParam("jobId") String jobId);
	
	@GET
	@Path("applyproject")
	@Produces("application/json")
	String applyproject(@QueryParam("jobId") String jobId,@QueryParam("userid") String userid);

}
