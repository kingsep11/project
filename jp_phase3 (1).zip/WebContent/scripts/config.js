requirejs.config({
    baseUrl: 'scripts/',
    paths: {
        // the left side is the module ID,
        // the right side is the path to
        // the jQuery file, relative to baseUrl.
        // Also, the path should NOT include
        // the '.js' file extension. This example
        // is using jQuery 1.9.0 located at
        // js/lib/jquery-1.9.0.js, relative to
        // the HTML page.
        'jquery': 'jquery/jquery-1.10.2.min',
        'jquery_ui':'jquery/jquery-ui.custom.min',
        'jquery_migrate':'jquery/jquery-migrate-1.2.1.min',
        'jquery_ui_slide':'jquery/jquery.ui.slider.min',
        'jquery_dataTables':'jquery/jquery.dataTables.min-1.10',
        //'jquery_datatable_twitter_pagination':'jquery/jquery.datatable.twitter.bs.pagination',
        'bootstrap':'scripts/bootstrap/bootstrap.2-32.min',
        'bootstrap-popover':'scripts/bootstrap/bootstrap-popover',
        
        home:'jportal/home',
        custom:'jportal/custom',
        user:'jportal/user/user',
        postjob:'jportal/job/postjob',
        common:'jportal/common',
        pickjob:'jportal/job/pickjob'
    },
   shim:{
	   'jquery_ui':{dep:['jquery']},
	   'jquery_dataTables':{dep:['jquery']}
	   //'jquery_datatable_twitter_pagination':{dep:['jquery','jquery_dataTables']}
    }

});