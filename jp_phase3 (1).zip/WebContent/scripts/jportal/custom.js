var userObj=null;
define(['jquery','jquery_dataTables','common'], function ($,$datatable,$common) {
	//testing
	
	return function(){
		console.log("script triggered....");
		
		$common.chkUserSession();
		$common.bindMenukEvents();
		var dtTableBtnLbl="";

		if(sessionStorage.getItem("listJobevtType")==undefined || sessionStorage.getItem("listJobevtType")==null || sessionStorage.getItem("listJobevtType")=="LIST"){
			dtTableBtnLbl="Pick Now";
			paintTable("F","","LIST");
		}

		if(sessionStorage.getItem("listJobevtType")=="APPROVE"){
			dtTableBtnLbl="Approve Now";
			$("#subTitle").html("Pending Jobs to be approved");
			$("#searchDiv").remove();
			paintTable("F","","APPROVE");
		}
		
		$("#srchBtn").click(function(){
			dtTableBtnLbl="Pick Now";
			paintTable("T",$(".search-query").val(),"LIST");
		});
		
		
		
		
		function paintTable(srchFlag,srchString,listfor){
			var tableHTML = '<table id="project_table" class="ProjectTable dataTable" cellpadding="0" cellspacing="0" style="opacity: 1;">'+
			    '<thead class="ProjectTable-head">'+
		        '<tr>'+
		            '<th class="ProjectTable-header sorting_disabled ProjectTable-cell ProjectTable-summaryColumn title-col">'+
		                    'Job Title/Description'+
		                '</th>'+
		            '<th class="ProjectTable-header ProjectTable-cell ProjectTable-bidsColumn bids-col sorting">'+
		                    'Bids/Entries'+
		                '<span class="fl-icon-chevron-up"></span>'+
		            '</th>'+
		            '<th class="ProjectTable-header ProjectTable-cell ProjectTable-startedColumn started-col sorting_desc">'+
		                    'Started'+
		                '<span class="fl-icon-chevron-up"></span>'+
		            '</th>'+
		            '<th class="ProjectTable-header ProjectTable-cell ProjectTable-endColumn end-col sorting" style="display: none;">'+
		                    'Ends'+
		                '<span class="fl-icon-chevron-up"></span>'+
		            '</th>'+
		            '<th class="ProjectTable-header ProjectTable-cell ProjectTable-priceColumn price-col sorting">'+
		                    'Price (INR)'+
		                '<span class="fl-icon-chevron-up"></span>'+
		            '</th>'+
		            '<th class="ProjectTable-header sorting_disabled ProjectTable-cell ProjectTable-bookmarkColumn bookmark-col">'+
		                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12" class="flicon-bookmark">'+
		                    '<path d="M2 1c-.55 0-1 .31-1 .7v8.94c0 .31.54.47.85.25l3.79-2.65c.2-.14.51-.14.71 0l3.79 2.65c.31.22.85.06.85-.25V1.7C11 1.31 10.55 1 10 1H2z"></path>'+
		                '</svg>'+
		            '</th>'+
		            '<th>Budget</th>'+
		            '<th>Date</th>'+
		        '</tr>'+
		    '</thead><tbody class="ProjectTable-body">';
			
			
			
			var tableContent='';
			var tableEnd = '</tbody></table>';
			var table='';
			var workList = new Array();
			$.ajax({
				type:'GET',
				contentType:'application/json',
				//url:'http://localhost:8080/jp/rest/webservice/getWorks?srchFlag='+srchFlag+'&srchString='+srchString,
				url:'./webserviceInvokeservlet?wsname=getWorks&srchFlag='+srchFlag+'&srchString='+srchString+'&listfor='+listfor,
				success:function(data){
					tableContent='';
					console.log(data);
					workList = data.workVO.workList;
					
					$.each(workList,function(index,obj){
						
						var skillArray = obj.skillset.split(',');
						var skill_link = '';
						$.each(skillArray,function(i,skill){
							skill_link=skill_link+'<a class="hiddenlink" href="https://www.jp#r.in/jobs/php/">'+skill+'</a>,';
						});
						
						tableContent = tableContent+'<tr class="odd ProjectTable-row project-details" project_id="10557868" bid_placed_check="1" id="10557868" style="cursor: pointer;">'+
						   '<td class=" ProjectTable-cell ProjectTable-summaryColumn title-col">'+
						      '<ul class="promotion-flags promotions"></ul>'+
						      '<h2 class="ProjectTable-title">'+
						         '<span class="ProjectTable-titleIcon is-ProjectTable-titleIcon-project">'+
						            '<svg viewBox="0 0 22.4 19.7" class="flicon-desktop">'+
						               '<g fill="none">'+
						                  '<title>Desktop icon</title>'+
						                  '<path d="M21.8 15.7c0 .8-.6 1.5-1.4 1.5H2c-.8 0-1.4-.7-1.4-1.5V2.1C.6 1.3 1.2.6 2 .6h18.4c.8 0 1.4.7 1.4 1.5v13.6zM4.8 19h12.8M11.2 17.2V19"></path>'+
						                  '<circle cx="11.2" cy="15.3" r=".5"></circle>'+
						                  '<path d="M.6 13.5h21.2"></path>'+
						               '</g>'+
						            '</svg>'+
						         '</span>'+
						         '<a href="#">'+obj.workTitle+'</a>'+
						      '</h2>'+
						      '<p class="ProjectTable-description">'+obj.workDesc+'</p>'+
						      '<span class="ProjectTable-skills">'+skill_link+
						      '</span>'+
						   '</td>'+
						   '<td class=" ProjectTable-cell ProjectTable-bidsColumn bids-col">'+
						      '<div class="bids-col-inner" data-bids="1">'+
						         '1'+
						      '</div>'+
						   '</td>'+
						   '<td class=" ProjectTable-cell ProjectTable-startedColumn started-col sorting_1">Today<small>6d 23h</small>'+
						   '</td>'+
						   '<td class=" ProjectTable-cell ProjectTable-endColumn end-col" style="display: none;">Today<small>6d 23h</small>'+
						   '</td>'+
						   '<td class=" ProjectTable-cell ProjectTable-priceColumn price-col">'+
						      '<span class="average-bid">$'+obj.minBudget+'</span>'+
						      '<div>'+
						         '<a class="btn btn-success btn-mini bid-now ProjectTable-control" data-budget="'+obj.minBudget+'" data-title="'+obj.workTitle+'" data-desc="'+obj.workDesc+'" href="#" type="'+sessionStorage.getItem("listJobevtType")+'" data-id="'+obj.workId+'">'+
						         dtTableBtnLbl+
						         '</a>'+
						      '</div>'+
						   '</td>'+
						   '<td class=" ProjectTable-cell ProjectTable-bookmarkColumn bookmark-col">'+
						      '<a class="bookmark" data-project-id="10557868" data-type="p" data-action="on">'+
						         '<div class="bookmark-inner">'+
						            '<span data-toggle="popover" href="javascript:void(0)" data-placement="left" data-content="Bookmark this project" data-original-title="">'+
						               '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12" class="flicon-bookmark">'+
						                  '<path d="M2 1c-.55 0-1 .31-1 .7v8.94c0 .31.54.47.85.25l3.79-2.65c.2-.14.51-.14.71 0l3.79 2.65c.31.22.85.06.85-.25V1.7C11 1.31 10.55 1 10 1H2z"></path>'+
						               '</svg>'+
						            '</span>'+
						         '</div>'+
						      '</a>'+
						   '</td>'+
						   '<td>$'+obj.maxBudget+'</td>'+
						   '<td>'+obj.createdDate+'</td>'+
						'</tr>';

					});
				},
				error:function(){
					
				},
				complete:function(){
					table=tableHTML+tableContent+tableEnd;
					
					$("#tableDiv").html('');
					$("#tableDiv").html(table);
					var oTable = $("#project_table").DataTable({
						"paging":   true,
				        "ordering": true,
				        "info":     false,
				        "pageLength": 5,
				        "lengthMenu": [ 5, 10, 20, 50, 100 ],
				       /* 'columnDefs': [
				                       null,
				                       null,
				                       null,
				                       null,
				                       null,
				                       null,
				                       { 'sortable': true, 'visible':false,"targets": [6]},
				                       { 'sortable': true, 'visible':false,"targets": [7]},
				                       { "orderData":[ 7 ],   "targets": [ 2 ] }
				                   ],*/
				        //"drawCallback":hideColumn
				       
					});
					
						oTable.column(7).visible( false );
						oTable.column(6).visible( false );
						
						
						$("#project_table tbody").off();
						$("#project_table tbody").on('click','.btn-mini',function(){
							console.log("button clicked....."+$(this).attr('data-id'));
							sessionStorage.setItem('selectedJobId',$(this).attr('data-id'));
							sessionStorage.setItem('selectedJobTitle',$(this).attr('data-title'));
							sessionStorage.setItem('selectedJobDescr',$(this).attr('data-desc'));
							sessionStorage.setItem('selectedJobBudget',$(this).attr('data-budget'));
							window.location.href="pickjob.html";
						});
						
						
					$("#quantity-selector").change(function(){
						console.log($(this).val());
						var selIndex = $(this).val();
						if(selIndex == 0){
							oTable.order([[7,'desc']]).draw();
						}
						if(selIndex == 1){
							oTable.order([[7,'asc']]).draw();
						}
						if(selIndex == 2){
							oTable.order([[6,'desc']]).draw();
						}
						if(selIndex == 3){
							oTable.order([[6,'asc']]).draw();
						}

					});
					
				}
				});

			
			/*for(var i=0;i<=50;i++){
				table=table+tableContent;
			}*/

		}
	}
});