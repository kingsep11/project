define(['jquery','jquery_dataTables','common'], function ($,$datatable,$common) {
	return function(){
		$common.pageControlBySession("pickjob.html");
		$common.chkUserSession();
		$common.bindMenukEvents();
		
		showJobDetails();
		
		function showJobDetails(){
			var jobId = sessionStorage.getItem('selectedJobId');
			var jobtitle=sessionStorage.getItem('selectedJobTitle');
			var jobdescr=sessionStorage.getItem('selectedJobDescr');
			var jobbudget=sessionStorage.getItem('selectedJobBudget');
			
			$(".project_name").html(jobtitle);
			$(".jobdescr").html(jobdescr);
			
			if(sessionStorage.getItem("listJobevtType")=="LIST"){
				$("#project_status").html("Active");
			}
			if(sessionStorage.getItem("listJobevtType")=="APROVE"){
				$("#project_status").html("Pending Approval");
				$(".repostProjectButton").html("Approve")
			}
		}
		
		$(".repostProjectButton").click(function(){
			
			console.log(sessionStorage.getItem("listJobevtType"));
			var wsUrl = "";
			var userObj=JSON.parse(sessionStorage.getItem('user'));
			
			if(sessionStorage.getItem("listJobevtType")=="APPROVE"){
				wsUrl="./webserviceInvokeservlet?wsname=approveproject&jobId="+sessionStorage.getItem('selectedJobId');
			}
			
			if(sessionStorage.getItem("listJobevtType")=="LIST" || sessionStorage.getItem("listJobevtType")==null){
				wsUrl="./webserviceInvokeservlet?wsname=applyproject&jobId="+sessionStorage.getItem('selectedJobId')+"&userid="+userObj.userDto.uid;
			}
			
			console.log(wsUrl);
			$.ajax({
			    url: wsUrl,
			    type: 'GET',
			    success: function( data, textStatus, jQxhr ){
			    	$common.showNotification("Y","S","Saved Successfully!");
			    },
			    error: function( jqXhr, textStatus, errorThrown ){
			        console.log( errorThrown );
			        $common.showNotification("N","E","Error when saving....");
			    },
			    complete:function(){
			    	$common.showNotification("Y","S","Saved Successfully!");
			    }
			});
			
		});

	}
});