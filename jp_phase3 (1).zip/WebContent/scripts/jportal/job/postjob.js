define(['jquery','jquery_dataTables','common'], function ($,$table,$common) {
	return function(){
		console.log("post job loaded...");
		
		
		
		$common.pageControlBySession("postjob.html");
		/**
		 * This is a click function for saving new job
		 * */

		$(".PostProject-btn").click(function(){
			var userObj = $common.getUserObject();

			var job = {
				 "workTitle":$("#project-name").val(),
				 "workDesc":$("#project-description").val(),
				 "budgetType":"1",
				 "listType":"1",
				 "ownerId":userObj.userDto.uid,
				 "skillset":"1",
				 "minBudget":$("#project-budget").val()
							
			};
			
			postJob(job);
		});
		
		
		function postJob(job){
			var messageFromServer="";
			var messageStatus="";
			var logicStatus="";
			
			$.ajax({
			    url: './webserviceInvokeservlet?wsname=savework',
			    dataType: 'json',
			    type: 'POST',
			    contentType: 'application/json;charset=UTF-8',
			    data: JSON.stringify(job),
			    success: function( data, textStatus, jQxhr ){
			        console.log("post job success....");
			        console.log(JSON.stringify(data));
			        messageFromServer=data.workDto.message;
			        messageStatus=data.workDto.messageStatus;
			        logicStatus=data.workDto.logicStatus;
			    },
			    error: function( jqXhr, textStatus, errorThrown ){
			        console.log( errorThrown );
			        $common.showNotification("N","E","Applciation Error with post job ! Please click <a href=login.html>here</a> to back to application ");
			    },
			    complete:function(){
			    	$common.showNotification(logicStatus,messageStatus,messageFromServer);
			    }
			});
		}
	}
});