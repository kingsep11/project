define(['jquery','jquery_dataTables'], function ($) {
	return {
		
		
		
		
		bindMenukEvents:function(){
				$(".post-job").click(function(){
					console.log("post job clicked....");
					window.location.href="postjob.html";
				});
				
				$(".browse-job").click(function(){
					console.log("browse job clicked.........");
					window.location.href="listing.html";
				});
				
				$("#loginbtn,.login").click(function(){
					console.log("login clicked....");
					window.location.href="login.html";
				});
				
				$("#signupbtn").click(function(){
					console.log("login clicked....");
					window.location.href="login.html";
				});
				
				
				$("#listjobs").click(function(){
					sessionStorage.setItem("listJobevtType","LIST");
					window.location.href="listing.html";
				});
				
				$("#approvejobs").click(function(){
					sessionStorage.setItem("listJobevtType","APPROVE");
					window.location.href="listing.html";
				});

		},
		
		
		/** For checking if the user logged in based on enable menu**/
		chkUserSession:function(){
			console.log("called chkUserSession......");
			var userObj=null;
			/** if the user information available in session **/
			if(sessionStorage.getItem('user')!= undefined && sessionStorage.getItem('user')!= null)
			{
				console.log("user session available....");
				userObj=JSON.parse(sessionStorage.getItem('user'));
				console.log(userObj);
				
				
				if(userObj!=null && userObj.userDto.logicStatus=="Y"){
					$(".usertitle").html(userObj.userDto.userName);
					$(".login").remove();
				}
				
				
				if(userObj!=null && userObj.userDto.isadmin=="N"){
					$("#admindiv").remove();
				}
				
			}
			else{
				$("#admindiv").remove();
				$(".logout").remove();
			}
		},
		
		pageControlBySession:function(pagename){
			if(sessionStorage.getItem('user')!= undefined && sessionStorage.getItem('user')!= null)
			{
				if(pagename=="login.html"){
					window.location.href="listing.html";
				}
			}else{
				if(pagename=="pickjob.html" || pagename=="postjob.html"){
					window.location.href="login.html";
				}
			}
		},
		
		
		showNotification:function(logicStatus,messageStatus,message){
			
			if(logicStatus=="Y"){
				$("#message").show();
				$("#message").addClass("alert-success");
				$("#message").html(message);
			}else if(logicStatus=="Y" && messageStatus=="A"){
				$("#message").show();
				$("#message").removeClass("alert-success");
				$("#message").removeClass("alert-danger");
				$("#message").addClass("alert-warning");
				$("#message").html(message);

			}else{
				$("#message").show();
				$("#message").removeClass("alert-success");
				$("#message").removeClass("alert-warning");
				$("#message").addClass("alert-danger");
				$("#message").html(message);	
			}
			
		},
		
		getUserObject:function(){
			var userObj=JSON.parse(sessionStorage.getItem('user'));
			return userObj;
		}
		
	};
});