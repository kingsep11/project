console.log("hi iam node server started");

var express = require('express');
var fishApp = express();
var bodyParser = require('body-parser');
var http = require('http');
var path = require('path');
var cors = require('cors'); // to respond for cross origin
var server = http.createServer(fishApp);
var io = require('socket.io').listen(server);



var auction = require('./serviceroute/auction');
var user = require('./serviceroute/user');
var product = require('./serviceroute/product');

var userRouter = user(fishApp);
var auctionRouter = auction(fishApp,io);
var productRouter = product(fishApp);


/** body parser configuration */
fishApp.use(bodyParser.urlencoded({ extended: false }));
fishApp.use(bodyParser.json());

/** constant files configuration **/
fishApp.use(express.static(path.join(__dirname+'/public/dist/')));

/** cross origin configuration */
fishApp.use(cors()); //this configuration will respond for all origin


var currentPrice = 99;
io.on('connection', function(socket){ 
    console.log("connection to server established");
    socket.emit('priceUpdate',currentPrice);
	socket.on('bid', function (data) {
		currentPrice = parseInt(data);
		socket.emit('priceUpdate',currentPrice);
		socket.broadcast.emit('priceUpdate',currentPrice);
	});
 });


/** serveic url mapping configurations **/
fishApp.get('/*',function(req,res){
    res.sendFile(path.join(__dirname+'/public/dist/index.html'));
})

fishApp.get('/sayHello',(request,response)=>{

    var obj={name:'initial string'};
    var option ={
        host:'127.0.0.1',
        port:8080,
        path:'/sayHello',
        method:'GET'
    }

    http.request(option,(res)=>{
        var resBody='';
        res.setEncoding('utf-8');
        res.on('data',(chunk)=>{
            resBody+=chunk;
        });

        res.on('end',()=>{
            console.log(resBody);
            obj={
                name:resBody
            };
            response.json(obj);
        });

        res.on('error',(err)=>{
            console.log(err);
            obj={
                name:'error @ microservice call'
            };
            response.json(obj);
        });

    }).end();
    
    
});

fishApp.get('/getProductList',(request,response)=>{
    console.log("node layer getProductList called...");

    var option ={
        host:'127.0.0.1',
        port:8081,
        path:'/getProductList',
        method:'GET'
    }

    http.request(option,(res)=>{
        var resBody='';
        res.on('data',(chunk)=>{
            resBody+=chunk;
        });
        res.on('end',()=>{
            console.log(resBody);
            response.json(resBody);
        });
         res.on('error',(err)=>{
            console.log(err);
            obj={
                name:'error @ microservice call'
            };
            response.json(obj);
        });
    }).end();
})



server.listen(3000,()=>{
    console.log("port 3000 is running");
});
