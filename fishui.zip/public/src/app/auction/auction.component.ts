import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';

import * as io from 'socket.io-client';

import {AuctionService} from '../services/auction.service';
import { UserService } from '../services/user.service';

@Component({
    selector:'app-auction',
    templateUrl:'./auction.component.html',
    providers:[AuctionService,UserService]
})

export class AuctionComponent implements OnInit{

    auctionItems = [];
    currentBidItemTempList=[];
    auctActiveStatus:any;
    socket=null;
    selAuctId:number=1;
    bidObj={};
    constructor(private auctionService:AuctionService, private userService:UserService,private router:Router){

    }
    ngOnInit(){
        this.getAuctionItems();

        this.socket=io('http://127.0.0.1:3000/');
        this.socket.on('auctionListUpdate', function(data){
            this.auctionItems = data;
        }.bind(this));

        this.socket.emit('startAuctionCoundown');
        this.socket.on('updateAuctionLiveStatus', function(data){
            this.auctActiveStatus = data.timeCountDown.days;
            if(this.auctActiveStatus=="live"){
                this.auctActiveStatus="LIVE";
            }
        }.bind(this));

    }

    getAuctionItems(){
        this.auctionService.getAuctionItems(this.selAuctId).subscribe(
            (response)=>{
                //this.auctionItems=JSON.parse(response);
                this.auctionItems=response;
                console.log(this.auctionItems);
            }
        );
    }

    showDetails(product){
        console.log("show details invoked...");
        this.router.navigate(['/product',product.auctionAdmappingId]);
    }

    doBidding(product){

     if(!this.userService.loggedIn()){
         this.router.navigate(['/user']);
    }else{
            console.log(product);
            var bidMapId = product.auctionAdmappingId;
            var bidValue = product.currentBidValue;
            var currentUserId = this.userService.getLoggedInUserId();
            this.socket.emit('bid', bidMapId,bidValue);

            this.bidObj = {
                "adauctmap":bidMapId,
                "bidderid":currentUserId,
                "bidvalue":bidValue
            };

            this.auctionService.doBidNow(this.bidObj).subscribe(
                (response)=>{
                    //this.auctionItems=JSON.parse(response);
                    this.auctionItems=response;
                    console.log(this.auctionItems);
                }
            );

    }
    }
}