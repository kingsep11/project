import {Injectable} from '@angular/core';
import {Http,Response,RequestOptions,RequestMethod,Headers} from '@angular/http';
import 'rxjs/Rx';

@Injectable()
export class ProductService{

    constructor(private http:Http){}

    getProductList(){
        console.log("service layer....");
        return this.http.get('http://localhost:8081/getProductList').map(
            (response:Response) => {
                var data=response;
                return data.json();
            }
        );
    }

    findProductByAuctionMapId(auctionAdMapId){
        console.log("service layer....");
        return this.http.get('http://localhost:3000/findAuctionById/'+auctionAdMapId).map(
            (response:Response) => {
                var data=response;
                return data.json();
            }
        );
    }

    addNewProduct(product){
        console.log(JSON.stringify(product));
         return this.http.post('http://localhost:8081/addNewProduct',product).map(
            (response:Response) => {
                var data=response;
                return data.json();
            }
        );
    }

   getPendingAuctionList(){
          return this.http.get('http://localhost:8081/fetchUpcomingAuction').map(
            (response:Response) => {
                var data=response;
                return data.json();
            }
        );
    }


    addNewImage(adId:string,image:File){
        console.log(image);
        let formdata: FormData = new FormData();
         formdata.append('adId',adId);
         formdata.append('file', image);
         //let headers = new Headers({'Content-Type':'Multipart/form-data'});
        //let options = new RequestOptions({headers: headers});
         return this.http.post('http://localhost:8888/s3/upload',formdata).map(
            (response:any) => {
                var data=response;
                return data;
            }
        );
    }


        assignProductToListingType(adId:string,auctId:string){
        let formdata: FormData = new FormData();
         formdata.append('prodId',adId);
         formdata.append('auctId', auctId);
         return this.http.post('http://localhost:8081/assignToAuction',formdata).map(
            (response:Response) => {
                var data=response;
                return data.json();
            }
        );
    }

}