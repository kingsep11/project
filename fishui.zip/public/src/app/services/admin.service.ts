import {Injectable} from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/Rx';

@Injectable()
export class AdminService {

    host = "http://localhost:8085";
    nodeHost = "http://localhost:3000";

    constructor(private http:Http){}
    getPendintProductList(){
        return this.http.get(this.host+"/getPendintProductList").map(
            (response:Response)=>{
                console.log(response);
                return response.json()
            }
        )
    }

    reLoadAuctProductList(){
        return this.http.get(this.nodeHost+"/refreshProductFroAuction").map(
            (response:Response)=>{
                console.log(response);
                return response.json()
            }
        )
    }


    doApprove(product:any){
        return this.http.post(this.host+"/approveProduct",product).map(
            (response:Response)=>{
                console.log(response.json());
                return response.json()
            }
        )
    }


    onAddAuction(auction:any){
        return this.http.post(this.host+"/createNewAuction",auction).map(
            (response:Response)=>{
                console.log(response.json());
                return response.json()
            }
        )
    }
}