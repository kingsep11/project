import { Injectable } from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/Rx';

@Injectable()
export class AuctionService{

    constructor(private http:Http){

    }
    getAuctionItems(auctId:number){
        return this.http.get('http://localhost:3000/auctionitemlist').map(
            (response:Response)=>{
                console.log(response.json())
                return response.json();
            }
        )
    }

    doBidNow(bidObj:{}){
        return this.http.post('http://127.0.0.1:8083/savebidnowtodb',bidObj).map(
            (response:Response)=>{
                console.log("-----------------------");
                console.log(response.json())
                return response.json();
            }
        )
    }

}