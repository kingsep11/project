import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import 'rxjs/Rx';

@Injectable()
export class UserService{

    constructor(private http:Http){}
    helloUser(){
        console.log("user service layer called....");
        return this.http.get('http://localhost:3000/sayHello').map(
            (response:Response)=>{
                var data = response;
                console.log(data.json());
                return data.json();
            }
        );
    }


    saveUser(user){
        console.log(user);
        return this.http.post('http://localhost:8080/saveuser',user).map(
            (response:Response)=>{
                console.log(response.json());
                return response;
            }
        )
    }


    loginUser(user){
        return this.http.post('http://localhost:8080/login',user).map(
            (response:Response)=>{
                this.storeUserData(response.json());
                return response.json();
            }
        )
    }


    // Function to store user's data in client local storage
  storeUserData(user) {
    console.log(JSON.stringify(user));
    //var userObj = JSON.parse(user)
    var userObj = user;
    //localStorage.setItem('token', token); // Set token in local storage
    localStorage.setItem('userId', userObj.userId); 
    localStorage.setItem('userName', userObj.userName); 
    localStorage.setItem('userRole', userObj.userRole);
  }


  // Function to logout
  logout() {
    localStorage.clear(); // Clear local storage
  }


  // Function to check if user is logged in
  loggedIn() {
    //return tokenNotExpired();
    if(localStorage.getItem('userId') !=null && localStorage.getItem('userId')!=undefined){
        return true;
    }else{
        return false;
    }
  }

  getLoggedInUserId(){
      return localStorage.getItem('userId');
  }

   getLoggedInUserRole(){
      return localStorage.getItem('userRole');
   }
}