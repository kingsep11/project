import { Component, Input, ElementRef, ViewChild, OnInit, OnDestroy  } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { ActivatedRoute,Router } from '@angular/router';

/** importing services */
import { ProductService } from '../services/product.service';
import { UserService } from '../services/user.service';

@Component({
    selector:'image-upload',
    templateUrl:'./imageupload.component.html',
    providers:[ProductService,UserService]
})
export class ImageUploadComponent implements OnInit, OnDestroy {

    @Input() multiple:boolean;
    inputEl: any[];

    adId: string;
    private sub: any;
    newuploads:any;

    public uploader:FileUploader = new FileUploader({url:'http://localhost:8888/s3/upload'});
    constructor(private productService:ProductService,private userService:UserService,private route: ActivatedRoute,private router:Router){}

    ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
       this.adId = params['adId']; // (+) converts string 'id' to a number
       // In a real app: dispatch action to load the details here.
    });

    console.log(this.adId);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

    getFiles(event){ 
        this.inputEl = event.target.files; 
    } 


        onUploadImages(){
            /*this.newuploads={
                "name":"asdf.jpg",
                "file":ngForm.value.ufile
            };
            this.productService.addNewImage(this.newuploads).subscribe(
                (response:Response)=>{
                    console.log(response);
                }
          )*/
          console.log("image upload starts.....");
                //formData.append('file', inputEl1.FileList.item(i));
          //this.uploader.queue[0].upload(); 
            let inputEl1: any = this.inputEl;
            console.log(inputEl1);
            let fileCount: number = inputEl1.length;
            console.log("fileCount "+fileCount);
            console.log(inputEl1[0]);
            let formData = new FormData();
            if (fileCount > 0) { // a file was selected
                formData.append('adId',this.adId);
            for (let i = 0; i < fileCount; i++) {
                console.log(inputEl1[i]);
                formData.append('file', inputEl1[i]);
            }

            console.log(formData.getAll);
            this.productService.addNewImage(this.adId,inputEl1[0]).subscribe(
                (response:Response)=>{
                    console.log(response);
                    //if(response.status=="SUCCESS"){
                        setTimeout(()=>{
                            console.log("waiting 2 secs...");
                            this.router.navigate(['/assignlisttype',this.adId]);
                        },2000);
                    //}
                }
          )
          console.log("image upload completed.....");
        }
        }


}