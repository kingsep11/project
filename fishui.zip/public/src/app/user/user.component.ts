/**user component for user related activities */
import { Component,OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

import { Store } from '@ngrx/store';

import { UserService } from '../services/user.service';
import { UserModel } from '../models/user.model';
import { SaveUser } from '../actionandreducers/user.actions';

@Component({
    selector:'app-user',
    templateUrl:'./user.component.html',
    providers:[UserService]
})

export class UserComponent implements OnInit{
   newUser ={ }; loginUser={};
   errMessage="";
    
   constructor(private userService:UserService,private router:Router, private store:Store<any>){ }

   ngOnInit(){
        this.store.select('reducers').subscribe((state)=>{
            /*if(state.userReducer && state.userReducer.userData){
                console.log(state.userReducer.userData);
            }*/

            console.log(state.userData);
        })
   }
    onAddUser(ngForm:NgForm){
        this.newUser = {
            "userName":ngForm.value.userName,
            "email":ngForm.value.email,
            "password":ngForm.value.password,
            "phone":ngForm.value.phone
        }
        this.userService.saveUser(this.newUser).subscribe(
            (response)=>{
                console.log(response);
                this.errMessage="User Registration success";
                setTimeout(1000,()=>{
                    this.router.navigate(['user']);
                });
                
            }
        );
    };


     doLogin(ngForm:NgForm){
        this.loginUser = {
            "userName":ngForm.value.loginName,
            "email":null,
            "password":ngForm.value.loginpassword,
            "phone":null
        }
        this.userService.loginUser(this.loginUser).subscribe(
            (response)=>{
                console.log(response);
                if(response.userId == null){
                    this.errMessage="Username / Password Invalid";
                }else{
                    this.loginUser=response;
                    console.log(this.loginUser);
                    this.store.dispatch(new SaveUser(new UserModel(response.userId,response.userName,response.userRole)));
                    this.router.navigate(['auction']);
                }
            }
        );
    };

    onCancelUser(){
        console.log("cancel user clicked....");
    }
}