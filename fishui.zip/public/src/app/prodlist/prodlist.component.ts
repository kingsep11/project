import { Component,EventEmitter,OnInit } from '@angular/core';


/** importing services */

import { ProductService } from '../services/product.service';

@Component({
    selector:'prod-list',
    templateUrl:'./prodlist.component.html',
    providers:[ProductService]
})

export class ProductListComponent implements OnInit{

    prodList:any[];
    constructor(private prodService:ProductService){
        //this.getProductList();
    }

    ngOnInit(){
        this.getProductList();
    }

    getProductList(){
        console.log("get prod list clicked....");
        this.prodService.getProductList().subscribe(
            (response)=>{
               this.prodList = JSON.parse(response);
               console.log(this.prodList);
            }
        )
    }

}