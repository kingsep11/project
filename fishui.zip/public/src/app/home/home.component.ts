import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as io from 'socket.io-client';

/** service section import  */
import { UserService } from '../services/user.service';

@Component({
    selector:'app-home',
    templateUrl:'./home.component.html',
    providers:[UserService],
    styleUrls:['./home.component.css']
})

export class HomeComponent implements OnInit{

    title:string;
    socket=null;
    bidValue=null;
    price=0;

    auctStCountdown:any={};
    activeAuctionId:any;
    activeAuctionName:any;

    constructor(private userService:UserService,private router: Router){
        console.log("home component intiated.....");

        this.socket=io('http://127.0.0.1:3000/');
        this.socket.emit('startAuctionCoundown');
        this.socket.on('updateStCounterInUI', function(data){
            this.activeAuctionId=data.activeAuctionId;
            this.activeAuctionName=data.activeAuctionName;
            this.auctStCountdown = data.timeCountDown;
            //console.log(this.auctStCountdown);
        }.bind(this));
    }

    ngOnInit(){

    }

    bid(){
        /*this.socket.emit('bid', this.bidValue);
        this.bidValue = '';*/
    }

   sayHelloTouser(){
    this.userService.helloUser().subscribe(
        (response)=>{
            this.title = response.name;
        }
    );
   }

   showAuctionFishes(){
        this.router.navigate(['/auction']);
   }

   addFish(){
        this.router.navigate(['/addnewproduct']);
   }
}