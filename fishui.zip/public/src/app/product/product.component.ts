import { Component, Input,OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { Http } from '@angular/Http';

import { ProductService } from '../services/product.service';
import {AuctionService} from '../services/auction.service';
import { UserService } from '../services/user.service';

import * as io from 'socket.io-client';
var _ = require('lodash');

@Component({
    selector:'app-product',
    templateUrl:'./product.component.html',
    providers:[ProductService,UserService,AuctionService]
})

export class ProductComponent implements OnInit{

    public adTitle:any;
    public imgFileName:any;
    public adDescr:any;
    public adId:any;
    public adPrice:any;
    public ownerId:any;
    public lastBid:any;
    socket=null;
    auctionItems:any;
    public auctActiveStatus:any;
    public currentBidValue:any;
    _auctionMapId:any; // variable starting with _ is param from other page

    constructor(private prodService:ProductService,
                private userService:UserService,
                private auctionService:AuctionService,
                private router:ActivatedRoute,
                private route:Router){}

    ngOnInit(){

        /** for displaying currently selected products auction details */
         this.router.params.subscribe(params=>{
             this._auctionMapId=params['auctionMapId'];
            /*this.prodService.findProductByAuctionMapId(params['auctionMapId']).subscribe(
                (response)=>{
                    console.log(response);
               }
            )*/
        });


     this.socket=io('http://127.0.0.1:3000/');
        this.socket.on('auctionListUpdate', function(data){
            this.auctionItems = data;
            let product = this.findAuctionById(this._auctionMapId);
            console.log(product);
            this.adTitle=product.adTitle;
            this.adDescr=product.adDescr;
            this.imgFileName=product.imgFileName;
        }.bind(this));

    this.socket.emit('startAuctionCoundown');
        this.socket.on('updateAuctionLiveStatus', function(data){
            this.auctActiveStatus = data.timeCountDown.days;
            if(this.auctActiveStatus=="live"){
                this.auctActiveStatus="LIVE";
            }
        }.bind(this));

    }


    findAuctionById(auctionId){
    return _.find(this.auctionItems,(auctionItemObj)=>{
        console.log(auctionItemObj.auctionAdmappingId);
            return auctionItemObj.auctionAdmappingId == auctionId;
        })
    }


    doBidding(){
     if(!this.userService.loggedIn()){
         this.route.navigate(['/user']);
    }else{
            var bidMapId = this._auctionMapId
            var bidValue = this.currentBidValue;
            var currentUserId = this.userService.getLoggedInUserId();
            this.socket.emit('bid', bidMapId,bidValue);

            let bidObj = {
                "adauctmap":bidMapId,
                "bidderid":currentUserId,
                "bidvalue":bidValue
            };

            this.auctionService.doBidNow(bidObj).subscribe(
                (response)=>{
                    //this.auctionItems=JSON.parse(response);
                    this.auctionItems=response;
                    console.log(this.auctionItems);
                }
            );

    }
    }
}