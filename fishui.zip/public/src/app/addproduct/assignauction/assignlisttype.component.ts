/**
 * this component is to choose listing type to a product
 * when adding new product
 */

import { Component,OnInit,OnDestroy } from '@angular/core';
import {NgForm} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { ProductService } from '../../services/product.service';

@Component({
    selector:'assign-auction',
    templateUrl:'./assignlisttype.component.html',
    providers:[ProductService]
})

export class AssignListingTypeComponent  implements OnInit, OnDestroy{
    
    pendingAuctions : any[];
    adId: string;
    auctId:string;
    private sub: any;

    constructor(private productService:ProductService,private route:ActivatedRoute){}
    ngOnInit(){
            this.sub = this.route.params.subscribe(params => {
            this.adId = params['adId']; // In a real app: dispatch action to load the details here.
            });
            this.getPendingAuctionList();
    }

    ngOnDestroy() {
        this.sub.unsubscribe();
    }

    assignThisAuction(evnt){
        console.log(evnt);
        let target = evnt.target;
       this.auctId=target.id;
       console.log("-------------> "+this.auctId);
    }

    onAddListingtype(){
        //console.log(form.value.auctname);
        this.productService.assignProductToListingType(this.adId,this.auctId).subscribe(
            (response)=>{
                console.log(response);
            }
        )
    }

    getPendingAuctionList(){
        this.productService.getPendingAuctionList().subscribe(
            (data)=>{
                console.log(data);
                this.pendingAuctions=data;
            }
        )
        
    }
}