import {Component,OnInit} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';

/** importing services */
import { ProductService } from '../services/product.service';
import { UserService } from '../services/user.service';

@Component({
    selector:'add-product',
    templateUrl:'./addproduct.component.html',
    providers:[ProductService,UserService]
})

export class AddProductComponent  implements OnInit{
    newProduct = {};
    errMessage="";
    constructor(private productService:ProductService,private userService:UserService,private router:Router){}

      ngOnInit() {
          if(!this.userService.loggedIn()){
              this.router.navigate(['/user']); // go to login 
          }
      }

    onAddProduct(ngForm:NgForm){
     this.newProduct={
        "adId":0,
        "adTitle":ngForm.value.adTitle,
        "adDescr":ngForm.value.adDescr,
        "subcatId":1,
        "ownerId":this.userService.getLoggedInUserId(),
        "listingTypeId":1,
        "price":ngForm.value.price,
        "active":"N",
        "status":"PENDING"
     };

     this.productService.addNewProduct(this.newProduct).subscribe(
         (response)=>{
             console.log(response);
             setTimeout(()=>{
                 this.errMessage=response.message;
             },1000);             
             

             if(response.status=="SUCCESS"){
                 this.router.navigate(['/imageupload', response.paramId]);
             }
         }
     )
    }
}