import { Component, OnInit } from '@angular/core';
//import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
//import { FlashMessagesService } from 'angular2-flash-messages';

import { UserService } from '../services/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  providers:[UserService]
})
export class NavbarComponent implements OnInit {

 private loggedInUser : {
                    id:any,
                    userName:any,
                    userRole:any
          };
  constructor(
    //public authService: AuthService,
    public authService:UserService,
    private router: Router,
    private store:Store<any>
    //private flashMessagesService: FlashMessagesService
  ) { }

  // Function to logout user
  onLogoutClick() {
    this.authService.logout(); // Logout user
    //this.flashMessagesService.show('You are logged out', { cssClass: 'alert-info' }); // Set custom flash message
    this.router.navigate(['/']); // Navigate back to home page
  }

  ngOnInit() {
    this.store.select('reducers').subscribe((state)=>{
      if(state.userData){
            this.loggedInUser = {id:state.userData.id,userName:state.userData.userName,userRole:state.userData.userRole};
       }else{
          this.loggedInUser = {id:null,userName:'GUEST USER',userRole:null};
       }
     })
  }

}
