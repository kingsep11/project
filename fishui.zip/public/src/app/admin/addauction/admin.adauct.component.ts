import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

import { AdminService } from '../../services/admin.service';

  @Component({
        selector:'admin-add-auction',
        templateUrl:'./admin.adauct.component.html',
        providers:[AdminService]
  })

export class AdminAddAuctionComponent{

    newAuction={};

    constructor(private adminService:AdminService){

    }

    onAddAuction(f:NgForm){

        var stDate = f.value.date;

        this.newAuction={
            "auctionId":"0",
            "auctionName":f.value.adTitle,
            "auctionDescr":f.value.adDescr,
            "auctionSt":f.value.date,
            "auctionEnd":null,
            "active":"Y",
            "createdDate":null
        };

        this.adminService.onAddAuction(this.newAuction).subscribe(
            (data)=>{
                console.log(data);
            }
        )
    }
}