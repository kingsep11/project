import {Component,OnInit} from '@angular/core';

import { AdminService } from '../../services/admin.service';

@Component({
    selector:'admin-pending-list',
    templateUrl:'./admin.pendingprod.component.html',
    providers:[AdminService]
})
export class AdminPendingProdComponent  implements OnInit{

    prodList:any[];
    constructor(private adminService:AdminService){

    }

        ngOnInit(){
        this.getProductList();
        }

    getProductList(){
        console.log("get prod list clicked....");
        this.adminService.getPendintProductList().subscribe(
            (response)=>{
               this.prodList = response;
               console.log(this.prodList);
            }
        );


        this.adminService.reLoadAuctProductList().subscribe(
            (res)=>{
                console.log("reloading of auctio items on admin approval....");
            }
        )
    }

    doApprove(prod:any){
        this.adminService.doApprove(prod).subscribe(
            (response)=>{
               console.log(response);
               this.getProductList(); // calling again to get pending product list
            }
        );
    }


   doDeny(prod:any){
   }

}