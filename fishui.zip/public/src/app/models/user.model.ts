export class UserModel{
    public id:any;
    public userName:any;
    public userRole:any;

    constructor(id:any,userName:any,userRole:any){
            this.id=id;
            this.userName=userName;
            this.userRole=userRole;
    }
}