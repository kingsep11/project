import { BrowserModule } from '@angular/platform-browser';
import { NgModule,InjectionToken  } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Routes,RouterModule } from '@angular/router';
import { StoreModule,ActionReducerMap } from '@ngrx/store';

import { AppComponent } from './app.component';

import { FileSelectDirective, FileDropDirective } from 'ng2-file-upload';
/** custom components declaration*/
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { ProductComponent } from './product/product.component';
import { ProductListComponent } from './prodlist/prodlist.component';
import { AuctionComponent } from './auction/auction.component';
import { AddProductComponent } from './addproduct/addproduct.component';

import { NavbarComponent } from './navbar/navbar.component';
import { RegisterComponent } from './register/register.component';
import { AdminPendingProdComponent } from './admin/pendingprod/admin.pendingprod.component';
import { AdminAddAuctionComponent } from './admin/addauction/admin.adauct.component';
import { ImageUploadComponent } from './imageupload/imageupload.component';
import { AssignListingTypeComponent } from './addproduct/assignauction/assignlisttype.component';


import { userReducers } from './actionandreducers/user.reducer';

/** navigation router declaration */
const appRoutes:Routes=[
  {path:'',component:HomeComponent},
  {path:'user',component:UserComponent},
  {path:'products',component:ProductListComponent},
  {path:'auction',component:AuctionComponent},
  {path:'addnewproduct',component:AddProductComponent},
  {path:'register',component:RegisterComponent},
  {path:'admin',component:AdminPendingProdComponent},
  {path:'addauction',component:AdminAddAuctionComponent},
  {path:'imageupload/:adId',component:ImageUploadComponent},
  {path:'assignlisttype/:adId',component:AssignListingTypeComponent},
  {path:'product/:auctionMapId',component:ProductComponent}
];


export const reducers : ActionReducerMap<any> = {
  userReducer:userReducers
};

@NgModule({
  declarations: [
    AppComponent,FileSelectDirective,
    HomeComponent,
    UserComponent,
    ProductComponent,
    ProductListComponent,
    AuctionComponent,
    AddProductComponent,
    NavbarComponent,
    RegisterComponent,
    AdminPendingProdComponent,
    AdminAddAuctionComponent,
    ImageUploadComponent,
    AssignListingTypeComponent  
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    StoreModule.forRoot({reducers:userReducers})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
