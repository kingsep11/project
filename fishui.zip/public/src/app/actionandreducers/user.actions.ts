import { Action } from '@ngrx/store';

export const SAVE_USER = 'SAVE_USER';

export class SaveUser implements Action{
    public readonly type=SAVE_USER;
    public constructor(public payload:any){}
}

export type UserActions = SaveUser;