import * as UserAction from './user.actions';

import { UserModel } from '../models/user.model';

export interface UserState{
    userData:any;
}
export const initstate={
    userData:null
}

export function userReducers(state:UserState=initstate,action:any):UserState{
    switch(action.type){
        case UserAction.SAVE_USER:{
            return Object.assign({},state,{userData:Object.assign({},action.payload)});}
        default:
            return state;
    }
}