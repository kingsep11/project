var http = require('http');
var bodyParser = require('body-parser');
var session = require('client-sessions');

var product = function(app){

    var jsonParser = bodyParser.json()
    var urlencodedParser = bodyParser.urlencoded({ extended: false });


/**for session */
app.use(session({
  cookieName: 'session',
  secret: 'random_string_goes_here',
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
}));


    app.post('/addNewProduct',jsonParser,(request,response)=>{

        console.log(request.session.user.userId);
        var loggedInUser = request.session.user.userId;
        var reqObj = request.body;

        reqObj.ownerId = loggedInUser;

            var data = JSON.stringify(reqObj);
            console.log("----->"+data);
            headers = {
                'Content-Type': 'application/json',
                'Content-Length' : Buffer.byteLength(data, 'utf8')
            };
            var option ={
                host:'127.0.0.1',
                port:8081,
                path:'/addNewProduct',
                method:'POST',
                headers:headers
            };

            var saveReqObj = http.request(option,(res)=>{
                var resBody='';
                res.on('data',(chunk)=>{
                    resBody+=chunk;
                });

                res.on('end',()=>{
                    console.log(resBody);
                     response.send(resBody);
                });
            });

            saveReqObj.write(data);
            saveReqObj.end();

            saveReqObj.on('error',(e)=>{
                console.log(e);
            })
    })

}

module.exports = product;