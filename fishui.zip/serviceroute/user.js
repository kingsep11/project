var http = require('http');
var bodyParser = require('body-parser');
var session = require('client-sessions');

var user = function(app){
console.log("user routing initiated....");

/**for session */
app.use(session({
  cookieName: 'session',
  secret: 'random_string_goes_here',
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
}));

var jsonParser = bodyParser.json()
var urlencodedParser = bodyParser.urlencoded({ extended: false });


    app.post('/saveuser',jsonParser,(request,response)=>{
        console.log("----><");
        console.log(JSON.stringify(request.body));

        var data = JSON.stringify(request.body);
        headers = {
            'Content-Type': 'application/json',
            'Content-Length' : Buffer.byteLength(data, 'utf8')
        };
        var option ={
        host:'127.0.0.1',
        port:8080,
        path:'/saveUser',
        method:'POST',
        headers:headers
        };

        var resBody='';
        var postReq = http.request(option,(res)=>{
        
        res.on('data',(chunk)=>{
            resBody+=chunk;
        });

        res.on('end',()=>{
            response.send (resBody);
            console.log(resBody);
        });
        });
        postReq.write(data);
        postReq.end();
        postReq.on('error',(e)=>{
            console.log(e);
        })
        //response.end("ok");
    });



    app.post('/loginuser',jsonParser,(request,response)=>{
         var data = JSON.stringify(request.body);
        headers = {
            'Content-Type': 'application/json',
            'Content-Length' : Buffer.byteLength(data, 'utf8')
        };
        var option ={
        host:'127.0.0.1',
        port:8080,
        path:'/login',
        method:'POST',
        headers:headers
        };

        var resBody = '';
        var reqObj = http.request(option,(res)=>{
            res.on('data',(chunk)=>{
                resBody+=chunk;
            });

            res.on('end',()=>{
                console.log(resBody);
                var userObj = JSON.parse(resBody);
                console.log('user is valid....');
                if(userObj.userId!=null){
                    request.session.user=userObj;
                    console.log(request.session.user);
                }else{
                    console.log('invalid user....');
                }               
                response.send(resBody);
            })
        });
        reqObj.write(data);
        reqObj.end();
    });
}

module.exports=user;