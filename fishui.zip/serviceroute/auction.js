var http = require('http');
var _ = require('lodash');
var auction = function(app,io){

    var auctionListItems = [];
    var upcomingAuctions = [];
    var currentAuctionId=0;

console.log("loading product list for upcoming / current auctiond on server start");
loadUpComingAuction();
//loadProductsForAuction();

app.get('/refreshProductFroAuction',(request,response)=>{
    console.log("refresing the one time loaded product list");
    loadProductsForAuction();
    response.send(JSON.stringify(auctionListItems));
})

app.get('/fetchUpcomingAuction',(request,response)=>{
    console.log("refresing the auction list");
    loadUpComingAuction();
    response.send(JSON.stringify(upcomingAuctions));
})

app.get('/findAuctionById/:auctMapId',(request,response)=>{
    console.log("----------> "+request.params.auctMapId);
    var resp = findAuctionById(request.params.auctMapId);
    console.log(resp);
    response.send(resp);
});

function findAuctionById(auctionId){
    console.log("method called....");
    console.log(upcomingAuctions);
   return _.find(auctionListItems,(auctionItemObj)=>{
       console.log(auctionItemObj.auctionAdmappingId);
        return auctionItemObj.auctionAdmappingId == auctionId;
    })
}

function loadUpComingAuction(){
        headers = {
            'Content-Type': 'application/json'
        };
        var option ={
            host:'127.0.0.1',
            port:8081,
            path:'/fetchUpcomingAuction',
            method:'GET'
        };
    
        var resBody='';
        http.request(option,(res)=>
        {
        res.on('data',(chunk)=>{
            resBody+=chunk;
        });

        res.on('end',()=>{
            console.log(resBody);
            upcomingAuctions = JSON.parse(resBody);
            currentAuctionId=upcomingAuctions[0].auctionId;
            loadProductsForAuction();
         });
       
        }).end();
        
        console.log(upcomingAuctions);
}


function loadProductsForAuction(){
    console.log("currentAuctionId "+currentAuctionId);
    var data = {"auctId" : 1};
        headers = {
            'Content-Type': 'application/json'
        };
        var option ={
        host:'127.0.0.1',
        port:8081,
        path:'/fetchProdListForAuction?auctId='+currentAuctionId,
        method:'POST'
        };
    
        var resBody='';
        http.request(option,(res)=>{
             res.on('data',(chunk)=>{
            resBody+=chunk;
        });

        res.on('end',()=>{
           // response.send(resBody);
            console.log(resBody);
            auctionListItems = JSON.parse(resBody);
        });


    }).end();
}




io.on('connection', function(socket){ 
    console.log("connection to auction server established");
    socket.emit('auctionListUpdate',auctionListItems);

     /** for updating the bid value in the array to  */
    socket.on('bid', function (auctMapId,bidValue) {
        var bidItemIndex = -1;

        for(var i=0;i<auctionListItems.length;i++){
            if(auctionListItems[i].auctionAdmappingId == auctMapId){
                bidItemIndex = i;
                break;
            }
        }


        console.log("bidItemIndex "+bidItemIndex);
        var bidItem = auctionListItems[bidItemIndex];
        bidItem.adPrice = bidValue;
        auctionListItems[bidItemIndex] = bidItem;
        console.log(auctionListItems[bidItemIndex]);

		socket.emit('auctionListUpdate',auctionListItems);
		socket.broadcast.emit('auctionListUpdate',auctionListItems);
    });


    var timerIntervalToStart={};

    socket.on('startAuctionCoundown', function () {
        var currAuctId = upcomingAuctions[0].auctionId;
        var currAuctName = upcomingAuctions[0].auctionName;
        setInterval(function(){
        var paramDate = upcomingAuctions[0].auctionSt;
        var timer= timerCountown(paramDate);
        timerIntervalToStart={
            "activeAuctionId":currAuctId,
            "activeAuctionName":currAuctName,
            "timeCountDown":timer
        }
        socket.emit('updateStCounterInUI',timerIntervalToStart);
        },1000);
    });
    
 });


    app.get('/auctionitemlist',(request,response)=>{
        console.log("auction list get called...");

       /* var data = {"auctId" : 1};
        headers = {
            'Content-Type': 'application/json'
        };
        var option ={
        host:'127.0.0.1',
        port:8081,
        path:'/fetchProdListForAuction?auctId=1',
        method:'POST'
        };
    
        var resBody='';
        http.request(option,(res)=>{
             res.on('data',(chunk)=>{
            resBody+=chunk;
        });

        res.on('end',()=>{
            response.send(resBody);
            console.log(resBody);
        });

        }).end();*/

        console.log("------------------------>");
        console.log(auctionListItems);
        response.send(JSON.stringify(auctionListItems));
    })


    function timerCountown(paramDate){
         var retObj = {};
          var dateEntered = new Date(paramDate);
          //console.log(dateEntered);
            var now = new Date();
            var difference = dateEntered.getTime() - now.getTime();

            if (difference <= 0) {
                clearInterval(timer);
                retObj = {"days":"live","hours":"live","minutes":"live","seconds":"live"};
            } else {
                var seconds = Math.floor(difference / 1000);
                var minutes = Math.floor(seconds / 60);
                var hours = Math.floor(minutes / 60);
                var days = Math.floor(hours / 24);

                hours %= 24;
                minutes %= 60;
                seconds %= 60;

                retObj = {"days":days,"hours":hours,"minutes":minutes,"seconds":seconds};
            }

            return retObj;
    }
}
module.exports=auction;